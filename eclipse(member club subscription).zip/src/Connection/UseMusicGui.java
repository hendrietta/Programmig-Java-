package Connection;

public class UseMusicGui {
	public static void main(String[] args)
	{
	new MusicProgram();
	}
}
