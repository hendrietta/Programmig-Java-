package Junit;

public class Music {
	 private String name;
	 private String lastname;
	private String  address;
	private int age;
	public Music(String nameIn,String lastnameIn, String  addressIn, int ageIn)
	 {
	 name = nameIn;
	 lastname=lastnameIn;
	 address=addressIn;
	  age= ageIn;
	 }

	 public String getname()
	 {
	 return name;
	 }
	 
	public String getlastname()
	 {
	 return lastname;
	 }
	 
	 public String getaddress()
	 {
	 return address;
	 }
	 
	 public void setlastname(String lastnameIn)
	 {
	 lastname = lastnameIn;
	 }
	 
	 public void setname(String name)
	 {
	 name =name;
	 }
	 
	 public void setaddress(String addressIn)
	 {
	 address = addressIn;
	 }
	}
