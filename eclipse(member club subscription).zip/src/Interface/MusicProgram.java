package Interface;
import java.io.*;
import java.awt.*;
import javax.swing.*;

import Interface.MusicProgram;

import java.awt.event.*;
import java.sql.*;
import java.util.*;
public class MusicProgram {


    JFrame heading;
    JPanel  tabAdd,tabUpdateMember,tabDeleteMember,tabDisplayMember;
    JTabbedPane tp;

    JLabel name,lastname, address, age, UpdateName,UpdatelastName,UpdateAddress, UpdateAge,removeName,removeId,male,gender,comboBoxMusic,comboBoxMusicSet, my,anti, FavArtist;
    JTextField tf0,nameTextField,removeIdText,removeNameText,lastnameTextField,addressTextField,delete,ageText,textfieldUpdateName,UpdateAddressText,textfieldUpdatelastName,tf9,removeIdTextField,removeNameTextfield;
    JScrollPane sp1;
    JRadioButton on,off;
    JButton savebutton,resetbutton,editbutton,editbutton2,deletebutton,deleted ;
    JComboBox         MusicType,MusicTypeChoice;

    MusicProgram(){
    
        heading=new JFrame("Music Club");
        tabAdd=new JPanel(new GridLayout(10,10));
        tabAdd.setBackground(new Color(191,239,1));

        
        tabUpdateMember=new JPanel(new GridLayout(5,2));
        tabDeleteMember=new JPanel(new GridLayout(8,8));
        tabDisplayMember=new JPanel(new GridLayout(5,2));

        tabUpdateMember.setBackground(new Color(191,29,1));
        tabDeleteMember.setBackground(new Color(191,29,201));
        tabDisplayMember.setBackground(new Color(100,100,200));
        tp=new JTabbedPane();

        tp=new JTabbedPane();
        name=new JLabel("Name:");
        lastname=new JLabel("Last name:");
        address=new JLabel(" Address:");
        age=new JLabel("Age:");
        gender=new JLabel("Gender:");
        on = new JRadioButton("Female");
        male=new JLabel("");
        off = new JRadioButton("Male");
        FavArtist=new JLabel("Favourite Artist:");
        my=new JLabel("pick two music generes: ");
        MusicType = new JComboBox();
        comboBoxMusic=new JLabel(" ");
        MusicType= new JComboBox();
    
        anti=new JLabel("pick two music generes: ");
        MusicType = new JComboBox();
        comboBoxMusicSet=new JLabel(" ");
        MusicTypeChoice= new JComboBox();
        
        UpdateName=new JLabel("Update ID:");
        UpdatelastName=new JLabel("Update last Name:");
        UpdateAge=new JLabel("Update Age:");
        UpdateAddress=new JLabel("Update Address:");

        
        removeName=new JLabel("remove name:");
        removeId=new JLabel("remove id:");
        nameTextField=new JTextField(12);
        lastnameTextField=new JTextField(12);
        addressTextField=new JTextField(12);
        ageText=new JTextField(12);
        tf0=new JTextField(12);
        delete=new JTextField(12);
    
        textfieldUpdateName=new JTextField(12);
        textfieldUpdatelastName=new JTextField(12);
        tf9=new JTextField(12);
        UpdateAddressText=new JTextField(12);
        removeNameText=new JTextField(12);
        removeNameTextfield=new JTextField(12);
        removeIdText=new JTextField(12);
        savebutton=new JButton(" Add ");
        resetbutton=new JButton(" Reset");
        editbutton=new JButton(" Edit ");
        editbutton2=new JButton(" Save");
        deletebutton=new JButton("Delete");
        deleted=new JButton("Delete");
        tabAdd.add(name);
        tabAdd.add(nameTextField);
        tabAdd.add(lastname);
        tabAdd.add(lastnameTextField);
        tabAdd.add(address);
        tabAdd.add(addressTextField);
        tabAdd.add(age);
        tabAdd.add(ageText);
        tabAdd.add(gender);
        tabAdd.add(on);
        tabAdd.add(male);
        tabAdd.add(off);
        tabAdd.add(FavArtist);
        tabAdd.add(tf0);
        tabAdd.add(my);
        tabAdd.add(MusicType);
        MusicType.addItem("Afro-beats");

        MusicType.addItem("Hip pop");

        MusicType.addItem("Rap");

        MusicType.addItem("Rnb");

        MusicType.addItem("Jazz");
        tabAdd.add(anti);
        tabAdd.add(MusicTypeChoice);
        MusicTypeChoice.addItem("classics");

        MusicTypeChoice.addItem("Grim");

        MusicTypeChoice.addItem("Rap");

        MusicTypeChoice.addItem("Rnb");

        MusicTypeChoice.addItem("Jaz");
        tabAdd.add(savebutton);
        tabAdd.add(resetbutton);

        tabUpdateMember.add( UpdateName);
        tabUpdateMember.add(textfieldUpdateName);
        tabUpdateMember.add(UpdatelastName);
        tabUpdateMember.add(textfieldUpdatelastName);
        tabUpdateMember.add( UpdateAge);
        tabUpdateMember.add(tf9);
        tabUpdateMember.add(UpdateAddress);
        tabUpdateMember.add(UpdateAddressText);
        tabUpdateMember.add(editbutton);
        tabUpdateMember.add(editbutton2);

        tabDeleteMember.add(removeName);
        tabDeleteMember.add(removeNameText);
         tabDeleteMember.add(removeId);
        tabDeleteMember.add(removeIdText);
        
        tabDeleteMember.add(deletebutton);

        
        on.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent ae){
                    
                    
                }

            });
        resetbutton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent ae){
                    nameTextField.setText("");
                    lastnameTextField.setText("");
                    addressTextField.setText("");
                    ageText.setText("");
                    JOptionPane.showMessageDialog(tabAdd,"you have reset the form");
                }

            });
        savebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae){
                    String combine;
                    String name1=nameTextField.getText();
                    String lastname2=lastnameTextField.getText();
                    String address3=addressTextField.getText();
                    String age4=ageText.getText();
                    Connection con = null;
                    String url = "jdbc:mysql://localhost:3306/";
                    String db = "test";
                    String driver = "com.mysql.jdbc.Driver";
                    String user = "root";
                    String pass = "root";
                    System.out.println( name1+lastname2+address+age4);
                   combine= name1+lastname2+address+age4;
                   JOptionPane.showMessageDialog(tabAdd,"you have successfully added a member");
                }
            });

        deletebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae){

                    String value1=delete.getText();
                    Connection con = null;
                    String url = "jdbc:mysql://localhost:3306/";
                    String db = "test";
                    String driver = "com.mysql.jdbc.Driver";
                    String user = "root";
                    String pass = "root";
                    try{
                        Class.forName(driver);
                        con = DriverManager.getConnection(url+db, user, pass);
                        PreparedStatement st=con.prepareStatement("DELETE FROM employee WHERE emp_id = ?");
                        st.setString(1,value1);
                        st.executeUpdate();
                        JOptionPane.showMessageDialog(tabDeleteMember,"Record is deleted successfully.");
                        con.close();
                    }
                    catch(Exception exp3)
                    {
                        JOptionPane.showMessageDialog(tabDeleteMember,"Error in deleting record.");
                    }
                }
            });
        editbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae){

                    String value=textfieldUpdateName.getText();
                    Connection con = null;
                    String url = "jdbc:mysql://localhost:3306/";
                    String db = "test";
                    String driver = "com.mysql.jdbc.Driver";
                    String user = "root";
                    String pass = "root";
                    try{
                        Class.forName(driver);
                        con = DriverManager.getConnection(url+db, user, pass);
                        PreparedStatement st=con.prepareStatement("select * from employee where emp_id=?");
                        st.setString(1,value);
                        ResultSet res=st.executeQuery();
                        res.next();
                        textfieldUpdateName.setText(Integer.toString(res.getInt(1)));
                        textfieldUpdatelastName.setText(res.getString(2));
                        tf9.setText(res.getString(3));
                        UpdateAddressText.setText(Integer.toString(res.getInt(4)));
                        con.close();
                    }
                    catch(Exception e)
                    {
                        JOptionPane.showMessageDialog(tabUpdateMember,"Can not edit data");
                    }
                }
            });
        editbutton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae){
                    Connection con = null;
                    String url = "jdbc:mysql://localhost:3306/";
                    String db = "test";
                    String driver = "com.mysql.jdbc.Driver";
                    String user = "root";
                    String pass = "root";
                    try
                    {
                        int x=JOptionPane.showConfirmDialog(tabUpdateMember,"Confirm edit? All data will be replaced");
                        if(x==0){
                            try{
                                String value1=textfieldUpdateName.getText();
                                String value2=textfieldUpdatelastName.getText();
                                String value3=tf9.getText();
                                String value4=UpdateAddressText.getText();

                                Class.forName(driver);
                                con = DriverManager.getConnection(url+db, user, pass);;
                                Statement st=con.createStatement();

                            }
                            catch(Exception ex)
                            {
                                JOptionPane.showMessageDialog(tabUpdateMember,"Error in updating edit fields");
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        JOptionPane.showMessageDialog(tabUpdateMember,"Error");
                    }
                }
            });

    }

    void dis()
    {
        heading.getContentPane().add(tp);
        tp.addTab("Add Member",tabAdd);
        tp.addTab("Update Member",tabUpdateMember);
        tp.addTab("Delete Member",tabDeleteMember);
        tp.addTab("Display Members",tabDisplayMember);
        heading.setSize(550,450);
        heading.setVisible(true);
        heading.setResizable(true);
    }

    public static void main(String []args){
        MusicProgram TheWindow=new MusicProgram();
        TheWindow.dis();
    }

}

