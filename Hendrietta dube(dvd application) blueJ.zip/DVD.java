
/**
 * Write a description of class DVD here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DVD
{
    // the attributes
    private String dvdId;
    private String dvdName;
    private int ageClassification;
    private String Category;
    private int rating;
    private int numMinutes;
    private int lenOfTime;

    //constructor has the same name as class
    //made public so other classes can see it
    public DVD(String dvdIdIn, String dvdNameIn,int ageClassificationIn,String CategoryIn,int ratingIn, int numMinutesIn)
    {     
        
        
        dvdId=dvdIdIn;
        dvdName=dvdNameIn;
        ageClassification=ageClassificationIn;
        Category=CategoryIn;
        rating=ratingIn;
        numMinutes=numMinutesIn;
        lenOfTime=0;
    }
    //methods
    //getters
    public String getdvdId() //send back the value
    {
        return dvdId; 
    }
    
    public String getdvdName()
    {
        return dvdName;
    }
    
    public int getageClassification()
    {
        return ageClassification;
    }
    
    public String getCategory()
    {
        return Category;
    }
    
    public int getrating()
    {
        return rating;
    }
    
    public int getnumMinutes()
    {
        return numMinutes;
    }
    
    public int getlenOfTime()
    {
        return lenOfTime;
    }

    //setters
    public void setdvdId(String dvdIdIn)//does not return-return type is void
    {
        dvdId=dvdIdIn;
    }
    public void setdvdName(String dvdNameIn)
    {
        dvdName=dvdNameIn;
    }
    public void setageClassification(int ageClassificationIn)
    {
     ageClassification=ageClassificationIn;   
    }
    public void setCategory(String CategoryIn)
    {
        Category=CategoryIn;
    }
    public void setnumMinutes(int numMinutesIn)
    {
        numMinutes=numMinutesIn;
    }
    public void setlenOfTime(int lenOfTimeIn)
    {  
      lenOfTime=lenOfTimeIn;  
    }
    public void setrating(int ratingIn)
    {
        rating=ratingIn;
    }
}
