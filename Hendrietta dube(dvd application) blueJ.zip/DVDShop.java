
/**
 * Write a description of class DVDShop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DVDShop
{
    private DVD [] dvdList; //private array =creates an array
    private int total;

    public DVDShop(int sizeIn)
    {
        dvdList=new DVD[sizeIn];
        total=0;
    }

    public int getTotal()
    {
        return total;
    }

    public boolean add(DVD dvdlist)
    {
        if(isFull() == false)
        {
            dvdList[total] = dvdlist;         // this is an array
            total++;                                  // adding 1
            return true;                           // this means you could add the dvd
        }
        else
        {
            return false;                             // this is means you couldn't add the dvd
        }
    }

    public boolean remove(String dvdIdIn)
    {
        int index;
        index = search(dvdIdIn);
        if(index ==-999)
        {
            return false;
        }
        else
        {
            for(int i =index; i <= total -1; i++)
            {
                dvdList[index] =dvdList[index+1];
            }
            return true;
        }
    }

    public boolean isEmpty()
    {
        if(dvdList.length ==0)
        {
            return true;  //means the list is empty
        }
        else{
            return false; //its not empty

        }
    }

    public boolean isFull()
    {
        if(dvdList.length ==total)
        {
            return true;  //the list is full
        }
        else{
            return false; //the list is not full

        }
    }
    

    public DVD checkShortestDVD() {

        int time = 0;
        int shortest =0; 

        for(int i = 0; i < total; i--) {
           
            if(dvdList[i].getdvdId().compareTo=true))
            {
                return i;
            }
            else{
            }
        }
    }

    private int search(String dvdIdIn)
    {
        for(int i = 0; i< total; i++)
        {
            if(dvdList[i].getdvdId().equals(dvdIdIn))
            {
                return i;
            }
        }

        return -999;
    }

    public String list()
    {
        String theList="";
        if(isEmpty() ==true)
        {
            return theList;
        }
        else
        {
            for(int i= 0; i< total; i++)
            {
                theList =theList + "dvd id: "  +dvdList[i].getdvdId() + " dvd name : " +dvdList[i].getdvdName() + " age Classification: "+dvdList[i].getageClassification() + " Category: " +dvdList[i].getCategory()+ " rating: "+dvdList[i]. getrating()+" number of minutes: "+dvdList[i].getnumMinutes()+ " length time: "+dvdList[i].getlenOfTime()+"\n";
            }
            return theList;
        }
    }

    public DVD getItem(String dvdIdIn)
    {

        int find;
        find =search(dvdIdIn);

        if(find == -999) 
        {
            return null; //no storage 
        }
        else
        {
            return dvdList[find];
        }
    }

    public String UpDatelenOfTime()
    {

        
    }

    public boolean addDetails(String dvdId)
    {
         int index;
        index = search(dvdId);

        if(index == -999)
        {

            return false;
        }
        else
        {
            //add car
           dvdId[index] = dvdId;
            total++;
            return true;
        }  
    }
    }

