
/**
 * Write a description of class XtraVisonApplication here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class XtraVisonApplication
{
    public static void main(String args[])
    {
        int num;     //variables
        int choice;

        System.out.print("Enter the maximum number of dvds that can be stored in the shop ?");
        num = EasyScanner.nextInt();
         //creating an aray of type dvdshop
        DVDShop movie = new DVDShop(num); //creates array called movie of type dvdshop and holds objects of type dvdshop

        do //this the menu
        {
            System.out.println();
            System.out.println("DVD System");
            System.out.println("1. Add a DVD");
            System.out.println("2. remove a DVD");
            System.out.println("3. check if DVD Shop is empty");
            System.out.println("4. check if DVD Shop is full");
            System.out.println("5. Add Additional Dvd Details");
            System.out.println("6. Dvd details");
            System.out.println("7. Update DVD length of time in Store");
            System.out.println("8. Search DVD by Age Classification");
            System.out.println("9. Exit System");
            System.out.println();
            System.out.print("please Enter choice [1-9 only]:");  
            choice = EasyScanner.nextChar(); //which ever one is choosen it will skip everything

            switch(choice) //switch statement
            {
                case '1':
                addTheDvd(movie);
                break;

                case '2':
                removeDvd(movie);
                break;

                case '3':
                empty(movie);
                break;

                case '4':
                full(movie);
                break;

                case '5':
                addDetails(movie);
                break;

                case '6':
                showAll(movie);
                break;

                case '7':
                update(movie);
                break;

                case '8':
                search(movie);
                break;
                default:
                System.out.println("Please enter value choice (0-8 only)");
                break;

            }
        } while(choice !='0');
        System.out.println("Goodbye");
    }
   
    //static any changes made-made to all the objects
    private static void addTheDvd(DVDShop movie)//this methods adds a dvd to the system
    {
        System.out.print("Enter dvd id: " );
        String dvdId = EasyScanner.nextString();
        System.out.print("Enter dvd name: " );
        String dvdName = EasyScanner.nextString();
        System.out.print("Enter DVD category: " );
        String Category = EasyScanner.nextString();
        System.out.print("Enter DVD age classification: " );
        int ageClassification = EasyScanner.nextInt();
        System.out.print("Enter DVD running time (in minutes): " );
        int numMinutes = EasyScanner.nextInt();
        System.out.print("Enter DVD ratings :" );
        int rating = EasyScanner.nextInt();
        //creating dvd1 (object is Dvd)
        DVD dvd1 = new DVD( dvdId, dvdName,ageClassification, Category,numMinutes,rating);
        //creates an object of type dvd1 called dvd and sends 5 values
        boolean yes;
        yes =movie.add(dvd1);

        if(yes ==true)
        {
            System.out.println("The Dvd has been added to the system ");
        }
        else
        {
            System.out.println("The dv could not be added tothe System");
        }
    }

    private static void removeDvd(DVDShop movie)
    {
        String dvdId;
        System.out.print("Enter id of car you wish to delete: ");
        dvdId= EasyScanner.nextString();
        boolean yes;
        yes = movie.remove(dvdId);

        if(yes == true)
        {

            System.out.print("DVD with id number "+dvdId+" is removed");
        }

        else
        {
            System.out.print("Cannot delete DVD as no such DVD exist ");

        }
    }

    private static void  empty(DVDShop movie)
    {

        boolean empty;
        empty = movie.isEmpty();

        if(empty == true)
        {
            System.out.println("The DVD Shop is empty");     
        }

        else
        {

            System.out.println("The DVD Shop is not empty");
        }

    }
    private static void full(DVDShop movie)
    {
        boolean full;
        full= movie.isFull();

        if(full == true)
        {
            System.out.println("The DVD Shop is full");     
        }

        else
        {

            System.out.println("The DVD Shop is not full");
        }

    }
    
    private static void addDetails(DVDShop movie)
    {
        String dvdId;
        int rating;
        System.out.print("Enter dvd id: ");
        dvdId=EasyScanner.nextString();
        boolean yes;
        yes = movie.add();

        if(yes == true)
        {

            System.out.print("Enter DVD ratings:");
            rating= EasyScanner.nextInt();
             System.out.println("Dvd details updated");
        }

        else
        {
            System.out.print("No such Dvd exists ");

        }
    }

    private static void showAll(DVDShop movie)
    {
        boolean yes;
        yes = movie.dvdId();
        int rating;

        if(yes == true)
        {

            System.out.print("Enter DVD ratings:");
            rating= EasyScanner.nextInt();
             System.out.println("Dvd details updated");
        }

        else
        {
            System.out.print("No such Dvd exists ");

        }
    }
    
    private static void  update(DVDShop movie)
    {
        String update;
        update= movie.UpDatelenOfTime();

        if(update ==-999) //invalid
        {
            System.out.println("lnformation is not updated");     
        }

        else
        {

            System.out.println("All information is updated");
        }


    }

    private static void search(DVDShop movie)
    {
        String age;
        System.out.print("Enter age Classification of DVDs to view: ");
        age = EasyScanner.nextString();

        DVD dvd1;

        dvd1 = movie.getItem(age);

        if(dvd1 == null)
        {
            System.out.print("There are no Dvds for the age classification"+age);
        }

        else
        {
            System.out.println("dvd id: " + dvd1.getdvdId()); //objectname.methodname
            System.out.println("Dvd name: " + dvd1.getdvdName());
            System.out.println("Dvd Classification " +dvd1.getageClassification());
            System.out.println("Dvd category: " + dvd1.getCategory());
            System.out.println("Dvd rating: " + dvd1.getrating());
            System.out.println("length of dvd: " + dvd1.getlenOfTime());
        }
    }
}
